#!/usr/bin/python                                                                                                                                             
#-*- coding: utf-8 -*-

import os,sys

sys.path.append(os.path.split(os.path.realpath(__file__))[0])
